import { messages, type Message, type InsertMessage } from "@shared/schema";

export interface IStorage {
  getMessages(sessionId: string): Promise<Message[]>;
  addMessage(message: InsertMessage): Promise<Message>;
}

export class MemStorage implements IStorage {
  private messages: Map<number, Message>;
  private sessionMessages: Map<string, number[]>;
  private currentId: number;

  constructor() {
    this.messages = new Map();
    this.sessionMessages = new Map();
    this.currentId = 1;
  }

  async getMessages(sessionId: string): Promise<Message[]> {
    const messageIds = this.sessionMessages.get(sessionId) || [];
    return messageIds.map(id => this.messages.get(id)!).filter(Boolean);
  }

  async addMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.currentId++;
    const timestamp = new Date();
    
    // Create a new message object with all required properties explicitly set
    const message: Message = {
      id,
      content: insertMessage.content,
      sessionId: insertMessage.sessionId,
      isUser: insertMessage.isUser ?? false, // Use nullish coalescing to default to false
      timestamp
    };
    
    this.messages.set(id, message);
    
    const sessionMessages = this.sessionMessages.get(message.sessionId) || [];
    sessionMessages.push(id);
    this.sessionMessages.set(message.sessionId, sessionMessages);
    
    return message;
  }
}

export const storage = new MemStorage();
