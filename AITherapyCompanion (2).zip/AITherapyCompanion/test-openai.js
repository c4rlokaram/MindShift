// Script to test the OpenAI API
import OpenAI from 'openai';
console.log('Beginning OpenAI API test...');

console.log('API Key in env:', process.env.OPENAI_API_KEY ? 'exists (starts with: ' + process.env.OPENAI_API_KEY.substring(0, 3) + '...)' : 'missing');

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

async function testOpenAI() {
  try {
    console.log('Attempting to call OpenAI API...');
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "user", 
          content: "Hello, this is a test message to verify the API is working. Please respond with 'API is working correctly.'"
        }
      ],
      max_tokens: 50
    });
    
    console.log('API Response:', response.choices[0].message.content);
    console.log('Test completed successfully!');
  } catch (error) {
    console.error('Error during API call:');
    console.error(error);
  }
}

testOpenAI();