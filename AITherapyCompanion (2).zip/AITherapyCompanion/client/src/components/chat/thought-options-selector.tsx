import { useState, useEffect } from "react";
import { Search } from "lucide-react";

interface ThoughtOption {
  id: number;
  text: string;
}

interface ThoughtOptionsSelectorProps {
  options: ThoughtOption[];
  onSelectOption: (optionId: number) => void;
  disabled: boolean;
}

export default function ThoughtOptionsSelector({ 
  options, 
  onSelectOption, 
  disabled 
}: ThoughtOptionsSelectorProps) {
  const [expanded, setExpanded] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredOptions, setFilteredOptions] = useState<ThoughtOption[]>([]);
  const [showAllCategories, setShowAllCategories] = useState(true);
  
  useEffect(() => {
    if (!searchTerm.trim()) {
      setFilteredOptions(options);
      setShowAllCategories(true);
      return;
    }
    
    // Filter options based on search term
    const filtered = options.filter(option => 
      option.text.toLowerCase().includes(searchTerm.toLowerCase())
    );
    
    setFilteredOptions(filtered);
    setShowAllCategories(false);
  }, [searchTerm, options]);

  if (!options || options.length === 0) {
    return null;
  }

  // Define categories for easier reference
  const categories = [
    { name: "ACHIEVEMENT & COMPETENCE", slice: [0, 5] },
    { name: "SOCIAL & RELATIONSHIPS", slice: [5, 10] },
    { name: "SELF-WORTH & IDENTITY", slice: [10, 15] },
    { name: "FUTURE & ANXIETY", slice: [15, 20] },
    { name: "WORK & LIFE SATISFACTION", slice: [20, 25] }
  ];

  return (
    <div className="w-full">
      {!expanded ? (
        <button
          onClick={() => setExpanded(true)}
          disabled={disabled}
          className="w-full py-3 px-4 bg-primary text-white rounded-lg hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-all text-center font-medium"
        >
          Choose from 25 different thought patterns
        </button>
      ) : (
        <div className="rounded-lg border border-gray-200 overflow-hidden">
          <div className="p-3 bg-gray-50 border-b border-gray-200 flex justify-between items-center">
            <h3 className="text-sm font-medium text-gray-700">Select a thought to transform</h3>
            <button 
              onClick={() => setExpanded(false)}
              className="text-gray-500 hover:text-gray-700"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </button>
          </div>
          
          {/* Search Bar */}
          <div className="p-2 border-b border-gray-200">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <Search className="h-4 w-4 text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search for a specific problem..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full py-2 pl-10 pr-4 border border-gray-300 rounded-md text-sm focus:ring-primary focus:border-primary"
              />
              {searchTerm && (
                <button
                  onClick={() => setSearchTerm("")}
                  className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-gray-600"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                  </svg>
                </button>
              )}
            </div>
          </div>
          
          <div className="max-h-60 overflow-y-auto p-1">
            {showAllCategories ? (
              // Show options grouped by category when not searching
              categories.map((category, index) => (
                <div key={index} className="my-2 px-2">
                  <h4 className="text-xs font-semibold text-gray-500 mb-1">{category.name}</h4>
                  {options.slice(category.slice[0], category.slice[1]).map((option) => (
                    <button
                      key={option.id}
                      onClick={() => {
                        onSelectOption(option.id);
                        setExpanded(false);
                        setSearchTerm("");
                      }}
                      disabled={disabled}
                      className="w-full text-left p-2 hover:bg-gray-50 rounded-md my-1 transition-colors disabled:opacity-50 disabled:cursor-not-allowed border border-gray-100 text-sm"
                    >
                      {option.text}
                    </button>
                  ))}
                </div>
              ))
            ) : (
              // Show filtered results when searching
              <div className="px-2">
                <h4 className="text-xs font-semibold text-gray-500 mb-1">SEARCH RESULTS</h4>
                {filteredOptions.length > 0 ? (
                  filteredOptions.map((option) => (
                    <button
                      key={option.id}
                      onClick={() => {
                        onSelectOption(option.id);
                        setExpanded(false);
                        setSearchTerm("");
                      }}
                      disabled={disabled}
                      className="w-full text-left p-2 hover:bg-gray-50 rounded-md my-1 transition-colors disabled:opacity-50 disabled:cursor-not-allowed border border-gray-100 text-sm bg-gray-50"
                    >
                      {option.text}
                    </button>
                  ))
                ) : (
                  <p className="text-sm text-gray-500 p-2">No matching thoughts found. Try a different search term.</p>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}