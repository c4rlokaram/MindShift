import { useEffect, useRef } from "react";
import MessageItem from "./message-item";
import TypingIndicator from "./typing-indicator";

interface Message {
  id: number;
  content: string;
  isUser: boolean;
  timestamp: string;
  sessionId: string;
}

interface ChatContainerProps {
  messages: Message[];
  isLoading: boolean;
  onLearnMoreClick?: (messageId: number) => void;
}

export default function ChatContainer({ 
  messages, 
  isLoading, 
  onLearnMoreClick 
}: ChatContainerProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  return (
    <main className="flex-1 overflow-hidden pt-[84px] pb-[160px] max-w-2xl mx-auto w-full">
      <div id="messages-container" className="h-full overflow-y-auto px-4 py-3">
        {messages.map((message) => (
          <MessageItem 
            key={message.id} 
            message={message} 
            onLearnMoreClick={onLearnMoreClick && !message.isUser ? () => onLearnMoreClick(message.id) : undefined}
          />
        ))}
        
        {isLoading && <TypingIndicator />}
        
        <div ref={messagesEndRef} />
      </div>
    </main>
  );
}
