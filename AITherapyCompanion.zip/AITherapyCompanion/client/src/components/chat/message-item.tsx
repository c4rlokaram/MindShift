import { Zap, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import ReactMarkdown from 'react-markdown';

interface Message {
  id: number;
  content: string;
  isUser: boolean;
  timestamp: string;
  sessionId: string;
}

interface MessageItemProps {
  message: Message;
  onLearnMoreClick?: () => void;
}

export default function MessageItem({ message, onLearnMoreClick }: MessageItemProps) {
  const { content, isUser } = message;
  
  if (isUser) {
    return (
      <div className="message user-message mb-4 flex justify-end">
        <div className="bg-primary rounded-lg rounded-tr-none p-3 shadow-sm max-w-[85%]">
          <p className="text-white">{content}</p>
        </div>
      </div>
    );
  }
  
  // Separate the example part from the main content if it exists
  const hasExample = content.includes("*Example:");
  let mainContent = content;
  let exampleContent = "";
  
  if (hasExample) {
    const parts = content.split("*Example:");
    mainContent = parts[0].trim();
    exampleContent = parts[1].trim();
  }
  
  // Format AI message content with paragraphs
  const paragraphs = mainContent.split('\n').filter(p => p.trim() !== '');
  
  return (
    <div className="message ai-message mb-4">
      <div className="flex items-start">
        <div className="flex-shrink-0 h-8 w-8 rounded-full bg-primary flex items-center justify-center mr-2">
          <Zap className="h-5 w-5 text-white" />
        </div>
        <div className="bg-white rounded-lg rounded-tl-none p-3 shadow-sm max-w-[85%]">
          {paragraphs.map((paragraph, index) => (
            <p key={index} className={`text-gray-700 ${index > 0 ? 'mt-2' : ''}`}>
              {paragraph}
            </p>
          ))}
          
          {hasExample && (
            <div className="mt-3 bg-gray-50 p-3 rounded-md border-l-4 border-primary">
              <p className="text-sm font-medium text-gray-700 mb-1">Example:</p>
              <p className="text-sm text-gray-600">{exampleContent}</p>
            </div>
          )}
          
          {onLearnMoreClick && !content.includes("Welcome to Mindshift") && (
            <div className="mt-3 flex justify-end">
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={onLearnMoreClick}
                className="text-primary hover:text-primary-dark hover:bg-primary-50 flex items-center"
              >
                <BookOpen className="h-3 w-3 mr-1" />
                <span className="text-xs">Learn More</span>
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
