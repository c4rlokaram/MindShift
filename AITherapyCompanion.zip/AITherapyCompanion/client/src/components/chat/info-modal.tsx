import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface InfoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function InfoModal({ isOpen, onClose }: InfoModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader className="mb-4">
          <DialogTitle className="text-lg font-semibold text-gray-800">About Mindshift</DialogTitle>
          <DialogDescription className="text-gray-600">
            Transform negative thoughts into positive, empowering perspectives
          </DialogDescription>
        </DialogHeader>
        
        <div className="text-gray-600 space-y-3">
          <p>How to use:</p>
          <ol className="list-decimal pl-5 space-y-1">
            <li>Choose a negative thought from the options or search for one</li>
            <li>Read the positive perspective provided</li>
            <li>Click "Learn More" for additional guidance</li>
            <li>Try the "Positive Message" button for an instant mood lift</li>
          </ol>
          <p className="text-sm italic mt-2">
            This tool is not a replacement for professional mental health support. 
            If you're experiencing a crisis, please contact a healthcare provider or emergency services.
          </p>
        </div>
        
        <DialogFooter className="mt-5 sm:justify-center">
          <Button 
            onClick={onClose} 
            className="w-full bg-primary hover:bg-primary/90 text-white font-medium py-2 px-4 rounded-md transition-colors"
          >
            Got it
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
