import { Zap } from "lucide-react";

export default function TypingIndicator() {
  return (
    <div className="message ai-message mb-4">
      <div className="flex items-start">
        <div className="flex-shrink-0 h-8 w-8 rounded-full bg-primary flex items-center justify-center mr-2">
          <Zap className="h-5 w-5 text-white" />
        </div>
        <div className="bg-white rounded-lg rounded-tl-none p-3 shadow-sm">
          <div className="flex space-x-1">
            <div className="h-2 w-2 bg-gray-300 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></div>
            <div className="h-2 w-2 bg-gray-300 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
            <div className="h-2 w-2 bg-gray-300 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
          </div>
        </div>
      </div>
    </div>
  );
}
