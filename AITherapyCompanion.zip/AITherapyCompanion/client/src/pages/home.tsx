import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import ChatContainer from "@/components/chat/chat-container";
import ThoughtOptionsSelector from "@/components/chat/thought-options-selector";
import InfoModal from "@/components/chat/info-modal";
import { Button } from "@/components/ui/button";

interface Message {
  id: number;
  content: string;
  isUser: boolean;
  timestamp: string;
  sessionId: string;
}

interface ThoughtOption {
  id: number;
  text: string;
}

export default function Home() {
  const [sessionId, setSessionId] = useState<string>("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [showLearnMore, setShowLearnMore] = useState(false);
  const [selectedMessageId, setSelectedMessageId] = useState<number | null>(null);
  const { toast } = useToast();
  const messageEndRef = useRef<HTMLDivElement>(null);

  // Initialize session ID on first load
  useEffect(() => {
    const storedSessionId = localStorage.getItem("mindshift_session_id");
    if (storedSessionId) {
      setSessionId(storedSessionId);
    } else {
      const newSessionId = `session_${Date.now()}`;
      localStorage.setItem("mindshift_session_id", newSessionId);
      setSessionId(newSessionId);
    }

    // Show modal on first visit
    const hasVisitedBefore = localStorage.getItem("mindshift_visited");
    if (!hasVisitedBefore) {
      setIsModalOpen(true);
      localStorage.setItem("mindshift_visited", "true");
    }
  }, []);

  // Fetch thought options
  const { 
    data: thoughtOptions 
  } = useQuery({
    queryKey: ['/api/thought-options'],
    refetchOnWindowFocus: false
  });
  
  // Fetch messages
  const { 
    data: messages, 
    isLoading,
    isError,
    refetch 
  } = useQuery({
    queryKey: [`/api/messages/${sessionId}`],
    enabled: !!sessionId,
    refetchOnWindowFocus: false
  });

  // Transform thought mutation
  const transformMutation = useMutation({
    mutationFn: async (data: { optionId?: number, isPositiveMessage?: boolean }) => {
      const response = await apiRequest(
        "POST", 
        "/api/transform", 
        { ...data, sessionId }
      );
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/messages/${sessionId}`] });
      
      // Scroll to the bottom after messages update
      setTimeout(() => {
        messageEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to transform thought. Please try again.",
        variant: "destructive"
      });
    }
  });

  const handleSelectOption = async (optionId: number) => {
    await transformMutation.mutateAsync({ optionId });
  };

  const handlePositiveMessage = async () => {
    await transformMutation.mutateAsync({ isPositiveMessage: true });
  };

  // Add initial welcome message if no messages and not loading
  useEffect(() => {
    const addWelcomeMessage = async () => {
      if (
        sessionId && 
        !isLoading && 
        !isError && 
        messages && 
        messages.length === 0 && 
        !transformMutation.isPending
      ) {
        // Send welcome message
        const response = await apiRequest(
          "POST", 
          "/api/transform", 
          { 
            optionId: 0, // Special case for welcome message
            sessionId 
          }
        );
        
        queryClient.invalidateQueries({ queryKey: [`/api/messages/${sessionId}`] });
      }
    };

    addWelcomeMessage();
  }, [sessionId, messages, isLoading, isError]);

  return (
    <div className="bg-gray-100 font-sans min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm py-4 px-4 sm:px-6 fixed top-0 w-full z-10">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <div className="flex flex-col">
            <h1 className="text-xl font-semibold text-gray-800">Mindshift</h1>
            <p className="text-sm text-gray-500">Transform negative thoughts into positive perspectives</p>
          </div>
          <button 
            onClick={() => setIsModalOpen(true)}
            className="text-gray-500 hover:text-primary transition-colors p-2 rounded-full"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </button>
        </div>
      </header>

      {/* Chat Container */}
      <ChatContainer 
        messages={messages || []} 
        isLoading={isLoading || transformMutation.isPending}
        onLearnMoreClick={(messageId) => {
          setSelectedMessageId(messageId);
          setShowLearnMore(true);
        }} 
      />

      {/* Thought Options and Positive Message Buttons */}
      <div className="fixed bottom-0 left-0 right-0 bg-white shadow-lg p-4">
        <div className="max-w-2xl mx-auto flex flex-col space-y-4">
          <div className="flex flex-col space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-700">Choose a negative thought to transform:</p>
              </div>
              <div className="flex-shrink-0 ml-4">
                <Button
                  onClick={handlePositiveMessage}
                  variant="outline"
                  className="bg-gradient-to-r from-indigo-400 to-purple-500 hover:from-indigo-500 hover:to-purple-600 text-white border-0"
                  disabled={transformMutation.isPending}
                >
                  <span className="flex items-center">
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      className="h-4 w-4 mr-2" 
                      fill="none" 
                      viewBox="0 0 24 24" 
                      stroke="currentColor"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                    Positive Message
                    <span className="text-xs ml-1 opacity-70">(unlimited uses)</span>
                  </span>
                </Button>
              </div>
            </div>
            
            <ThoughtOptionsSelector 
              options={thoughtOptions || []} 
              onSelectOption={handleSelectOption} 
              disabled={transformMutation.isPending}
            />
          </div>
        </div>
      </div>

      {/* Info Modal */}
      <InfoModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
      />
      
      {/* Learn More Modal */}
      {showLearnMore && selectedMessageId && messages && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[80vh] overflow-auto p-6">
            <h3 className="text-lg font-semibold mb-4">Detailed Information</h3>
            <div className="prose prose-sm mb-6">
              <p>
                When you have negative thoughts, it's important to recognize that these thoughts are not facts. 
                They're often influenced by cognitive distortions - patterns of thinking that aren't accurate 
                reflections of reality.
              </p>
              <h4>Some common cognitive distortions include:</h4>
              <ul>
                <li><strong>All-or-nothing thinking:</strong> Seeing things in black and white categories</li>
                <li><strong>Overgeneralization:</strong> Viewing a single negative event as a never-ending pattern</li>
                <li><strong>Mental filtering:</strong> Focusing exclusively on negative elements while filtering out positives</li>
                <li><strong>Jumping to conclusions:</strong> Making negative interpretations without definite facts</li>
                <li><strong>Catastrophizing:</strong> Exaggerating the importance of problems</li>
              </ul>
              <h4>Practical steps you can take:</h4>
              <ol>
                <li>Notice when you're having negative thoughts</li>
                <li>Question these thoughts and look for evidence that contradicts them</li>
                <li>Practice self-compassion - speak to yourself as you would to a good friend</li>
                <li>Focus on what you can control or influence</li>
                <li>Consider speaking with a mental health professional for personalized guidance</li>
              </ol>
              <p className="italic text-gray-600">
                Remember that changing thought patterns takes time and practice. Be patient with yourself 
                as you develop this skill.
              </p>
            </div>
            <div className="flex justify-end">
              <Button 
                onClick={() => setShowLearnMore(false)}
                className="bg-primary text-white"
              >
                Close
              </Button>
            </div>
          </div>
        </div>
      )}
      
      {/* Reference for scrolling */}
      <div ref={messageEndRef} />
    </div>
  );
}
