// Dedicated responses for each multiple choice option
import { thoughtOptions } from "@shared/schema";

interface PositiveMessage {
  message: string;
}

// At least 20 different positive messages
const positiveMessages: PositiveMessage[] = [
  { message: "You matter more than you know. Your presence in this world makes a difference to someone." },
  { message: "Every challenge you face is strengthening something in you that you'll need later. You're becoming more resilient every day." },
  { message: "Progress isn't always visible, but that doesn't mean it isn't happening. Small steps forward still move you in the right direction." },
  { message: "You deserve kindness, especially from yourself. Try speaking to yourself today as you would to someone you love." },
  { message: "Your worth isn't measured by your productivity or achievements. You are inherently valuable just as you are." },
  { message: "This moment is just one part of your story, not the whole narrative. Better chapters are still waiting to be written." },
  { message: "You've survived 100% of your difficult days so far. That's an incredible track record of resilience!" },
  { message: "The fact that you're trying already shows courage. Sometimes the bravest thing is just showing up each day." },
  { message: "You have unique gifts that no one else can offer. The world needs your specific perspective." },
  { message: "It's okay to rest and recharge. Taking care of yourself isn't selfish—it's necessary." },
  { message: "Your feelings are valid messengers, not permanent states. They provide information but don't define who you are." },
  { message: "Small moments of joy are just as significant as big achievements. Notice and celebrate them." },
  { message: "Compassion for yourself creates space for growth. You don't have to be perfect to be worthy of love." },
  { message: "You are capable of change and growth in ways you might not yet imagine. Your potential is still unfolding." },
  { message: "Behind every successful person are countless setbacks and moments of doubt. Persistence matters more than perfection." },
  { message: "Your struggles don't diminish your value—they're part of what makes you human and helps you connect with others." },
  { message: "Something that comes easily to one person might be challenging for another, and vice versa. We all have different strengths." },
  { message: "Hope isn't about ignoring difficulty—it's about believing that something better is possible, even when it's hard to see." },
  { message: "Asking for help is a sign of wisdom, not weakness. We all need support sometimes." },
  { message: "You don't have to have everything figured out right now. Life unfolds one step at a time." },
  { message: "Your story is still being written. Today's chapter doesn't determine how the book ends." },
  { message: "When you can't control what's happening, you can still choose how you respond to it. That power is always yours." },
  { message: "The care you show for others reflects qualities within you that are beautiful and meaningful. Those qualities remain even when you're struggling." },
  { message: "Each sunrise offers new possibilities. Today is a fresh opportunity to move toward what matters to you." },
  { message: "The world is better because you're in it, bringing your unique perspective and qualities that no one else has in exactly the same way." },
  { message: "You're not alone in this. There are people who care about you, and they're here to support you every step of the way." }
];

// Track used positive messages to avoid repetition
let usedPositiveMessageIndices: number[] = [];

export function getRandomPositiveMessage(): string {
  // If all messages have been used, reset the tracking array
  if (usedPositiveMessageIndices.length >= positiveMessages.length) {
    usedPositiveMessageIndices = [];
  }
  
  // Find an unused message index
  let randomIndex: number;
  do {
    randomIndex = Math.floor(Math.random() * positiveMessages.length);
  } while (usedPositiveMessageIndices.includes(randomIndex));
  
  // Mark this index as used
  usedPositiveMessageIndices.push(randomIndex);
  
  // Return the message
  return positiveMessages[randomIndex].message;
}

export async function transformThought(text: string): Promise<string> {
  try {
    console.log("Using dedicated responses for multiple choice options");
    
    // Handle special case for positive message button
    if (text === "__POSITIVE_MESSAGE__") {
      return getRandomPositiveMessage();
    }
    
    // Create a map of responses for each specific thought option
    const responses: Record<string, string> = {
      // Achievement and competence concerns
      "I failed an exam and I feel useless": 
        "Exams are just one measurement at one moment in time, not a reflection of your overall worth or abilities. Many successful people have failed exams and gone on to achieve great things. Consider what specific aspects of your preparation could be adjusted next time. Breaking down your study approach into smaller components might reveal areas for improvement. Remember that resilience—the ability to learn from setbacks—is often more valuable in life than perfect performance. What's one study strategy you could try differently next time?\n\n*Example: Jamie failed an important certification exam and felt like a complete failure. Instead of giving up, they analyzed which sections they struggled with and found a study group for those specific topics. Six weeks later, they not only passed but scored above average in their previously weakest areas.*",
      
      "I keep making mistakes at work and might get fired":
        "Making mistakes at work is a universal experience, though it can feel isolating when you're going through it. Consider documenting the specific errors and looking for patterns—is there a particular type of task or time of day when mistakes are more common? This information can help you develop targeted strategies. Remember that most employers value people who can acknowledge errors, learn from them, and improve. What kind of support or resources might help you feel more confident in your role? Creating a simple checklist or asking for clarification when needed can make a significant difference.\n\n*Example: Alex kept making errors in client reports and was afraid of losing their job. They created a personal quality-control checklist and started reviewing work in the morning when they were most alert. Their error rate dropped by 80%, and their manager noticed the improvement without Alex even mentioning it.*",
      
      "I'm not smart enough to succeed in my field":
        "Intelligence isn't fixed—it's developed through learning and practice in specific areas. Many successful professionals once felt exactly as you do now. The 'impostor phenomenon' is especially common in fields that require complex skills. Consider that if you're noticing areas where you need to improve, that awareness itself demonstrates valuable insight. What specific knowledge or skills would help you feel more confident? Breaking these down into small, manageable learning goals makes progress more achievable and visible. Your determination to improve already shows important qualities for success.\n\n*Example: Jordan felt out of depth among colleagues with prestigious degrees. Instead of giving up, they identified specific knowledge gaps and spent 30 minutes each morning studying before work. Six months later, they were contributing valuable ideas in meetings and received recognition for a project that leveraged their unique perspective.*",
      
      "I feel like an impostor and everyone will find out":
        "Impostor feelings are incredibly common, especially among high-achievers and those breaking new ground. Research shows that up to 70% of people experience these feelings at some point. This mindset often comes from attributing successes to external factors like luck while attributing failures to personal inadequacy. Try keeping an 'evidence journal' where you record accomplishments and positive feedback. What specific evidence contradicts your impostor narrative? Remember that feeling unprepared isn't the same as being unprepared—even experts continue learning throughout their careers.\n\n*Example: Taylor, despite consistent promotions, felt they were fooling everyone. They started recording specific contributions they made in meetings and positive feedback received. Gradually, they recognized patterns of strengths they brought to their team that others genuinely valued.*",
      
      "My business is failing and it's all my fault":
        "When a business struggles, it's rarely due to just one factor or person. Market conditions, timing, resources, and many external factors all play significant roles. Consider separating what's within your control from what isn't, and focus your energy on the former. What specific aspects of the business could benefit from adjustment? Sometimes the difference between success and failure is simply persistence through difficult periods. Many successful entrepreneurs failed multiple times before finding the right approach. Your willingness to take responsibility shows integrity, but balance that with realistic perspective.\n\n*Example: Sasha's new restaurant was losing money after six months. Instead of taking it all personally, they analyzed customer feedback, adjusted the menu to focus on high-margin popular items, and negotiated better terms with suppliers. The business became profitable within three months of these targeted changes.*",
      
      // Social and relationship concerns
      "Nobody likes me, I'm always alone": 
        "That feeling of disconnection can be really painful. Our minds often amplify negative social experiences while filtering out positive ones. Sometimes we also misinterpret neutral interactions as negative when we're feeling vulnerable. Consider if there have been any moments, even small ones, where someone showed they valued your presence. Connection often begins with gentle self-disclosure and genuine curiosity about others. What's one small step you might take to initiate contact with someone? Remember that meaningful connections take time to develop, and many people feel similarly lonely but don't express it.\n\n*Example: Robin felt invisible at work and in social settings. They started asking one thoughtful question to a colleague each day and joining a hobby group that met weekly. After two months, they had two new friendships developing and regular lunch companions at work.*",
      
      "I'll never find someone who loves me":
        "This thought creates a painful sense of permanent loneliness, but relationships come into our lives at different times and in unexpected ways. The path to connection isn't linear or predictable. Consider that preparing for a relationship often means developing your relationship with yourself first. What qualities would you appreciate in a partner? How might you cultivate some of those qualities in yourself? Engaging with activities you genuinely enjoy not only enriches your life but increases chances of meeting compatible people. Remember that many people find meaningful relationships at different life stages.\n\n*Example: Casey had been single for years and felt permanently unlovable. They focused on developing their passion for community gardening, which brought fulfillment regardless of relationship status. Through this activity, they developed a supportive social circle and eventually met a partner who shared their values.*",
      
      "My friends only tolerate me out of pity":
        "This thought reflects 'mind-reading'—assuming you know others' thoughts and motivations, which we cannot actually know with certainty. Friendships generally require ongoing investment of time and energy that people rarely sustain out of mere pity. What evidence might suggest your friends actually value your company? Consider small actions like them initiating contact, remembering details about your life, or choosing to spend time with you when they have other options. If uncertainty persists, deepening one friendship through more authentic sharing might provide reassurance about your place in others' lives.\n\n*Example: Morgan was convinced friends only included them out of obligation. When they noticed their friend Pat regularly sending memes specifically related to their interests, remembering details from past conversations, and suggesting one-on-one activities, they realized these actions required genuine care that wouldn't make sense if motivated by pity.*",
      
      "I always say the wrong thing in social situations":
        "The belief that you 'always' say the wrong thing reflects all-or-nothing thinking that likely doesn't capture the full reality. Social interactions involve countless exchanges, and our minds tend to highlight perceived mistakes while glossing over neutral or positive moments. Consider whether you're holding yourself to an unrealistic standard of saying the 'perfect' thing. What would happen if you focused more on being curious and present rather than monitoring your own performance? Most people are far more concerned with how they're coming across than closely judging others.\n\n*Example: Jesse felt perpetually awkward at gatherings. They decided to experiment with asking more questions about others instead of worrying about sharing impressive things. To their surprise, several people later mentioned enjoying their conversations, and one person even called them a 'great listener.'*",
      
      "My relationship is falling apart and it's my fault":
        "Relationships involve two people, each contributing to both problems and solutions. Taking full responsibility for relationship difficulties actually removes the other person's agency and role. Consider which aspects truly are your responsibility, which belong to your partner, and which are shared. What specific behaviors (not character traits) might you adjust? Remember that all relationships go through difficult periods, and working through challenges can sometimes create stronger connections when both people are willing to grow. Your awareness and concern already show that you care about improving the situation.\n\n*Example: Sam blamed themselves entirely for their relationship problems. When they talked with their partner, they discovered their partner was also feeling responsible for different aspects of their difficulties. They agreed to work on specific behaviors—Sam would communicate needs more clearly, while their partner would make more time for connection—which gradually improved their relationship.*",
      
      // Self-worth and identity concerns
      "I'll never be good enough": 
        "When we think in terms of 'never' and 'good enough,' we create an impossible standard that moves further away the closer we get. Everyone has different strengths and struggles—even people who seem to 'have it all together.' Instead of comparing yourself to an idealized standard, what would it look like to acknowledge your progress in specific areas? Small improvements compound over time. What's one area where you've grown recently that you might be overlooking? Your worth isn't determined by your achievements or others' validation—it's inherent in who you are.\n\n*Example: Riley constantly felt inadequate despite external success. They started noting one thing each day they did reasonably well, however small. After several weeks, they began recognizing patterns of strength they'd been overlooking, which gradually shifted their self-perception from 'never good enough' to 'growing and capable in many ways.'*",
      
      "I hate my body and how I look":
        "Our relationship with our bodies is deeply influenced by cultural messages that often set impossible standards. Consider that your body is not merely decorative—it's functional, carrying you through your life and enabling your experiences. What activities does your body allow you to do, even imperfectly? Shifting focus from appearance to capability and treating your body with care rather than criticism can gradually change your relationship with it. Remember that the people who matter most in your life value you for qualities that have nothing to do with your appearance.\n\n*Example: Quinn struggled with negative body image for years. They began a practice of thanking their body each day for specific functions ('Thank you, legs, for carrying me through my day') and reduced exposure to media that triggered comparison. Gradually, their focus shifted from appearance to appreciation, reducing the emotional pain associated with their body.*",
      
      "I'm a burden to everyone around me":
        "The feeling of being a burden often comes from valuing independence very highly and underestimating how interconnection naturally works in human relationships. We all need support at different times—being both givers and receivers creates balanced relationships. Consider the times you've supported others—did you resent them for needing help, or did it perhaps feel meaningful to contribute? What would you say to a friend who was afraid of burdening you with their needs? Your concerns about others' well-being already demonstrate consideration that makes helping you feel worthwhile to those who care about you.\n\n*Example: Lee felt they were constantly imposing on friends when asking for support during a difficult time. When their friend was later going through challenges, Lee willingly helped without resentment. This experience helped them recognize that mutual support strengthens rather than burdens relationships when balanced over time.*",
      
      "I don't deserve to be happy":
        "The belief that happiness must be earned or deserved often stems from messages we've internalized from others. Consider whether you apply this same standard to other people—do they need to 'deserve' happiness? What qualities or actions would make someone worthy of well-being, in your view? Recognizing that you wish happiness for others regardless of 'deservingness' can help extend that same perspective to yourself. Happiness isn't a reward for good behavior—it's a natural state that becomes accessible when we remove the obstacles to it, including beliefs about not deserving it.\n\n*Example: Avery believed happiness was for other people who had 'earned' it. When they realized they wanted happiness for a friend who had made similar mistakes, they began questioning their double standard. They started with 'permission' to enjoy small pleasures without justification, which gradually expanded their capacity for well-being.*",
      
      "I feel so stupid for making this mistake": 
        "Making mistakes is a universal human experience, not an indication of intelligence or capability. In fact, people who achieve mastery in their fields often make more mistakes because they're willing to try, learn, and adjust. Could you view this situation as information rather than judgment? What specific insight does this experience offer that might be valuable moving forward? Sometimes our most useful learning comes from the very moments we wish hadn't happened. How might you speak to yourself with the same kindness you'd offer someone else in this situation?\n\n*Example: Morgan accidentally copied the wrong person on an important email and felt devastated. Instead of continuing to berate themselves, they implemented a new practice of double-checking recipient fields before sending sensitive information. This mistake led to improved processes that prevented potentially larger problems later.*",
      
      // Future and anxiety concerns
      "I'm so anxious about my presentation tomorrow": 
        "That nervous energy you're feeling is your body preparing you to perform well—it shows you care about doing a good job. Remember that your audience wants you to succeed and likely won't notice small mistakes that seem huge to you. Preparation helps manage anxiety: practice your key points, take deep breaths before starting, and focus on connecting with your audience rather than achieving perfection. What's one small ritual that might help you feel more centered before you begin? Many accomplished speakers still get nervous—they've just learned to work with those feelings.\n\n*Example: Jamie had a major presentation and couldn't sleep from anxiety. They practiced the first five minutes repeatedly until it felt natural, prepared a simple grounding technique (feeling their feet on the floor while taking three deep breaths), and remembered a previous success. During the presentation, they focused on connecting with audience members who seemed engaged, which helped calm their nerves.*",
      
      "Everything always goes wrong for me": 
        "When we're going through difficult times, our attention naturally focuses on what's not working, making it seem like 'everything' is problematic. This perspective, while understandable, often doesn't capture the full picture. If you were to step back and look at your life with fresh eyes, what aspects—even small ones—might be working okay or even well? Sometimes identifying islands of stability in challenging times helps us feel more grounded. What's one thing, however modest, that's going reasonably well right now? This isn't about denying difficulties, but about gaining a more balanced perspective.\n\n*Example: Chris was dealing with multiple challenges—car problems, work stress, and health concerns—that made it feel like everything was falling apart. When they specifically listed what was actually working (their housing was stable, one close friendship remained supportive, their pet was healthy), they found small anchors of stability that helped them cope with the genuine difficulties they were facing.*",
      
      "I'll never achieve my dreams and goals":
        "When 'never' enters our thinking, it creates a sense of permanence that rarely reflects reality. Dreams and goals often unfold in unexpected ways and timelines. Consider whether your current goals are specific and broken into achievable steps, or if they're more general aspirations that feel overwhelming as a whole. What would be a small, concrete step toward something meaningful to you? Sometimes we also need to reconsider whether our goals still align with who we're becoming—it's okay for dreams to evolve as we do. What matters is continuing to move toward what's meaningful, even if the specific destination changes.\n\n*Example: Jordan had dreamed of being a published author since childhood but at 45 felt this would never happen. They committed to writing just 20 minutes each morning before work. While their initial novel remains unpublished, this practice led to opportunities writing for local publications, which brought unexpected satisfaction and a sense of accomplishment they hadn't anticipated.*",
      
      "I'm going to be alone forever":
        "The feeling of permanent aloneness can be incredibly painful. Our minds are prone to projecting current circumstances indefinitely into the future, though life rarely unfolds in such predictable ways. Connection can enter our lives through unexpected channels and at unexpected times. What would it look like to develop fulfilling aspects of your life now, creating a foundation that could support future relationships? Meaningful social connections come in many forms beyond romantic relationships—what other types of connections might bring value to your life? Taking small steps toward any form of authentic connection often creates ripple effects beyond what we can initially see.\n\n*Example: Kai was convinced they would always be alone after a difficult breakup. They reluctantly joined a hiking group to get outside more, with no expectations about meeting anyone. The regular activity improved their mood, led to casual friendships, and eventually a deeper connection with someone who shared their values—a possibility they couldn't envision when feeling hopelessly alone.*",
      
      "I'm worried I'll never overcome my anxiety":
        "Living with anxiety can make it feel like a permanent condition, especially during difficult periods. However, our relationship with anxiety can change significantly over time, even when the feelings themselves don't completely disappear. Many effective approaches exist for managing anxiety, from therapy to mindfulness practices to medication when appropriate. What small steps have helped, even temporarily, in the past? Consider that the goal might not be eliminating anxiety entirely, but developing a different relationship with it—one where it doesn't control your choices or define your identity. Many people live meaningful lives alongside anxiety, rather than waiting for it to disappear completely.\n\n*Example: Devon had struggled with anxiety for years and feared it would never improve. They started working with a therapist who helped them recognize their anxiety as one part of their experience rather than their entire identity. Through gradual exposure to challenging situations and self-compassion practices, the anxiety didn't disappear but became manageable enough that it no longer prevented them from participating in activities they valued.*",
      
      // Work and life satisfaction concerns
      "I hate my job, it's making me miserable": 
        "It's difficult spending so much time in an environment that feels draining. Before making any big decisions, it might help to identify the specific aspects of your job that feel most challenging. Are there particular tasks, relationships, or environmental factors contributing to your feelings? Sometimes small adjustments can significantly improve our experience. If change within your current role isn't possible, what small steps could you take to explore alternatives while maintaining stability? Remember that your job is something you do, not who you are—creating meaningful experiences outside work can help balance challenging work situations.\n\n*Example: Pat was increasingly miserable at work and dreaded each day. They made a detailed list of what specifically felt most difficult (micromanaging supervisor, long commute, lack of creative input) versus what worked well (stable income, two supportive colleagues, developing valuable skills). This clarity helped them negotiate working from home two days weekly and joining a creative project team, which significantly improved their experience while they explored longer-term options.*",
      
      "I've wasted years of my life on the wrong path":
        "The feeling of lost time can be painful, but viewing past choices as 'waste' doesn't recognize the learning and growth that occurred, even through difficult experiences. Every path provides skills, insights, and understanding that can inform your next steps. Consider what specific wisdom you've gained that someone just starting out wouldn't have. What transferable skills or perspectives have you developed? Rather than starting from zero, you're beginning your next chapter with resources you didn't have before. Many successful people made significant changes in direction at various points in their lives, bringing valuable experience from their previous paths.\n\n*Example: Jesse spent eight years in a career they ultimately decided wasn't right for them. Instead of seeing those years as wasted, they identified transferable skills (project management, communication, technical knowledge) that gave them advantages in their new field. Their 'wrong path' actually provided unique perspectives that differentiated them from colleagues who had followed more traditional routes.*",
      
      "I can't do anything right": 
        "When we're feeling down, our minds tend to overgeneralize failures while filtering out successes. This thinking pattern makes it seem like we're constantly failing when the reality is more balanced. If you were observing yourself as a compassionate friend would, what examples might you notice that contradict this belief? Even small daily actions that go well count as evidence. Consider keeping a simple record of things that go as planned or better each day—this can help recalibrate your perception over time. What's one small thing you've handled effectively recently that might be easy to overlook?\n\n*Example: Cameron felt completely incompetent after making several mistakes at work. When their therapist suggested noting things they did adequately or well each day, they were initially skeptical. After two weeks of recording even minor accomplishments (making a healthy meal, helping a colleague, completing routine tasks), they began noticing their mind automatically finding counter-examples when the 'can't do anything right' thought appeared.*",
      
      "I'm stuck in this situation with no way out":
        "The feeling of being trapped can be overwhelming, and sometimes our stress response narrows our thinking, making it harder to see possibilities. Even in genuinely restrictive circumstances, small degrees of choice and agency often exist. What aspects of your situation, however small, can you influence? Are there ways to create moments of relief or meaningful experience within the current constraints? Sometimes accepting difficult realities (without giving up on change) paradoxically creates mental space for new perspectives. Many people have navigated through seemingly impossible situations by taking one small step at a time without requiring certainty about the entire path.\n\n*Example: Fran felt hopelessly trapped in a difficult living situation they couldn't immediately leave due to financial constraints. They identified one corner of their space they could make more peaceful, one hour each evening for a calming activity, and began saving a small amount weekly. These small points of control and forward movement helped them manage emotionally while working toward a longer-term solution.*",
      
      "I should be further along in life by now":
        "The 'should' in this thought often comes from comparing our reality to an idealized timeline that doesn't account for individual circumstances, challenges, or paths. These comparisons are typically made against highlight reels of others or against our own imagined ideal, neither of which represents the full picture of real life. What external or internal messages shaped your expectations about timing? Consider what you've experienced or learned that wouldn't have happened on a different timeline. What would it look like to honor your actual journey rather than measuring it against an abstract standard? Progress happens at different rates in different areas of life for everyone.\n\n*Example: Alex felt behind in career development compared to former classmates. When they reflected on their unique circumstances—including caregiving responsibilities and health challenges they'd managed—they recognized they weren't 'behind' but on a different path with its own timeline. This realization helped them focus on their current opportunities rather than measuring against others' trajectories.*"
    };
    
    // Default response if text doesn't match any predefined option
    const defaultResponse = "I appreciate you sharing your thoughts with me. Remember that difficult feelings are temporary, even when they don't feel that way. What small step might help you move toward what matters to you right now? You've shown courage in expressing yourself—that's an important step in working through challenges.";
    
    // Return the specific response if it exists, otherwise return the default
    return responses[text] || defaultResponse;
    
  } catch (error) {
    console.error("Error transforming thought:", error);
    
    // Fallback response in case of error
    return "I appreciate you sharing your thoughts with me. Sometimes looking at situations from a different angle can help us find new perspectives. What's one small positive step you could take today? Remember that your feelings are valid, but they don't define you. You have the strength to work through this challenge.";
  }
}
