import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { transformThought, getRandomPositiveMessage } from "./openai";
import { thoughtTransformationSchema, insertMessageSchema, thoughtOptions } from "@shared/schema";
import { z } from "zod";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // prefix all routes with /api
  
  // Get all messages for a session
  app.get("/api/messages/:sessionId", async (req, res) => {
    try {
      const sessionId = req.params.sessionId;
      const messages = await storage.getMessages(sessionId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // Get all thought options
  app.get("/api/thought-options", (req, res) => {
    try {
      res.json(thoughtOptions);
    } catch (error) {
      console.error("Error fetching thought options:", error);
      res.status(500).json({ message: "Failed to fetch thought options" });
    }
  });

  // Get a random positive message
  app.get("/api/positive-message", (req, res) => {
    try {
      const message = getRandomPositiveMessage();
      res.json({ message });
    } catch (error) {
      console.error("Error getting positive message:", error);
      res.status(500).json({ message: "Failed to get positive message" });
    }
  });

  // Transform a thought
  app.post("/api/transform", async (req, res) => {
    try {
      // Get or create session ID
      const sessionId = req.body.sessionId || `session_${Date.now()}`;
      
      // Special case for welcome message (optionId: 0)
      if (req.body.optionId === 0) {
        // Add welcome message
        const welcomeMessage = insertMessageSchema.parse({
          content: "Welcome to Mindshift! Select a negative thought below to transform it into a more positive perspective, or click 'Positive Message' for an uplifting message.",
          isUser: false,
          sessionId
        });
        
        const savedMessage = await storage.addMessage(welcomeMessage);
        
        return res.json({
          message: savedMessage,
          sessionId
        });
      }
      
      // Special case for positive message button
      if (req.body.isPositiveMessage === true) {
        // Get a random positive message
        const positiveMessage = getRandomPositiveMessage();
        
        // Store AI response
        const aiMessage = insertMessageSchema.parse({
          content: positiveMessage,
          isUser: false,
          sessionId
        });
        
        const savedMessage = await storage.addMessage(aiMessage);
        
        return res.json({
          message: savedMessage,
          sessionId
        });
      }
      
      // For regular thought transformation, validate request
      const validatedData = thoughtTransformationSchema.parse(req.body);
      const { optionId } = validatedData;
      
      // Find the thought option text based on the option ID
      const selectedOption = thoughtOptions.find(option => option.id === optionId);
      
      if (!selectedOption) {
        return res.status(400).json({ message: "Invalid option selected" });
      }
      
      // Store user message
      const userMessage = insertMessageSchema.parse({
        content: selectedOption.text,
        isUser: true,
        sessionId
      });
      
      await storage.addMessage(userMessage);
      
      // Transform the thought using our transformation logic
      // Pass the full text of the selected option
      const transformedThought = await transformThought(selectedOption.text);
      
      // Store AI response
      const aiMessage = insertMessageSchema.parse({
        content: transformedThought,
        isUser: false,
        sessionId
      });
      
      const savedMessage = await storage.addMessage(aiMessage);
      
      // Return the transformed thought and session ID
      res.json({
        message: savedMessage,
        sessionId
      });
    } catch (error) {
      console.error("Error transforming thought:", error);
      
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to transform thought"
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
