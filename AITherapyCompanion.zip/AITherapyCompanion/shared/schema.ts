import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Message schema
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  isUser: boolean("is_user").notNull().default(false),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  sessionId: text("session_id").notNull(),
});

export const insertMessageSchema = createInsertSchema(messages).pick({
  content: true,
  isUser: true,
  sessionId: true,
});

export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;

// Define thought options for multiple choice
export const thoughtOptions = [
  // Achievement and competence concerns
  { id: 1, text: "I failed an exam and I feel useless" },
  { id: 2, text: "I keep making mistakes at work and might get fired" },
  { id: 3, text: "I'm not smart enough to succeed in my field" },
  { id: 4, text: "I feel like an impostor and everyone will find out" },
  { id: 5, text: "My business is failing and it's all my fault" },
  
  // Social and relationship concerns
  { id: 6, text: "Nobody likes me, I'm always alone" },
  { id: 7, text: "I'll never find someone who loves me" },
  { id: 8, text: "My friends only tolerate me out of pity" },
  { id: 9, text: "I always say the wrong thing in social situations" },
  { id: 10, text: "My relationship is falling apart and it's my fault" },
  
  // Self-worth and identity concerns
  { id: 11, text: "I'll never be good enough" },
  { id: 12, text: "I hate my body and how I look" },
  { id: 13, text: "I'm a burden to everyone around me" },
  { id: 14, text: "I don't deserve to be happy" },
  { id: 15, text: "I feel so stupid for making this mistake" },
  
  // Future and anxiety concerns
  { id: 16, text: "I'm so anxious about my presentation tomorrow" },
  { id: 17, text: "Everything always goes wrong for me" },
  { id: 18, text: "I'll never achieve my dreams and goals" },
  { id: 19, text: "I'm going to be alone forever" },
  { id: 20, text: "I'm worried I'll never overcome my anxiety" },
  
  // Work and life satisfaction concerns
  { id: 21, text: "I hate my job, it's making me miserable" },
  { id: 22, text: "I've wasted years of my life on the wrong path" },
  { id: 23, text: "I can't do anything right" },
  { id: 24, text: "I'm stuck in this situation with no way out" },
  { id: 25, text: "I should be further along in life by now" }
] as const;

export type ThoughtOption = typeof thoughtOptions[number];

// Schema for the thought transformation request
export const thoughtTransformationSchema = z.object({
  optionId: z.number().int().min(1).max(thoughtOptions.length),
});

export type ThoughtTransformation = z.infer<typeof thoughtTransformationSchema>;
